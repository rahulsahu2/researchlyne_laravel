<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
  <title><?php echo e(config('app.name')); ?></title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Sites meta Data -->
  <meta name="application-name" content="<?php echo e(config('app.name')); ?>">
  <meta name="author" content="<?php echo e(config('app.name')); ?>">
  <meta name="keywords" content="<?php echo e(config('app.name')); ?>">
  <meta name="description" content="<?php echo e(config('app.name')); ?>">

  <!-- OG meta data -->
  <meta property="og:title" content="<?php echo e(config('app.name')); ?>">
  <meta property="og:site_name" content=<?php echo e(config('app.name')); ?>>
  <meta property="og:url" content="<?php echo e(url('/')); ?>">
  <meta property="og:description" content="<?php echo e(config('app.name')); ?>">
  <meta property="og:type" content="<?php echo e(config('app.name')); ?>">
  <meta property="og:image" content="assets/images/og.png">

  <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/x-icon" />

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>" media="all" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/swiper-bundle.min.css')); ?>">

  <!-- main css for template -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>

  <!-- ===============>> Preloader start here <<================= -->
  <div class="preloader">
    <img src="<?php echo e(asset('assets/images/logo/preloader.png')); ?>" alt="preloader icon">
  </div>
  <!-- ===============>> Preloader end here <<================= -->



  <!-- ===============>> light&dark switch start here <<================= -->
  <div class="lightdark-switch">
    <span class="switch-btn" id="btnSwitch"><img src="<?php echo e(asset('assets/images/icon/moon.svg')); ?>" alt="light-dark-switchbtn"
        class="swtich-icon"></span>
  </div>
  <!-- ===============>> light&dark switch start here <<================= -->

  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('content'); ?>

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- ===============>> scrollToTop start here <<================= -->
  <a href="#" class="scrollToTop scrollToTop--style1"><i class="fa-solid fa-arrow-up-from-bracket"></i></a>
  <!-- ===============>> scrollToTop ending here <<================= -->


  <!-- vendor plugins -->

  <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/all.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/fslightbox.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/purecounter_vanilla.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
</body>
</html><?php /**PATH D:\Sachdeva Clinet\reserchlyne website new\researchlyne_laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>
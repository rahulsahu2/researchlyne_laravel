@extends('layouts.app')
@section('content')
<!-- ===============>> Banner section start here <<================= -->
<section class="banner banner--style1">
    <div class="banner__bg">
        <div class="banner__bg-element">
        <img src="assets/images/banner/home1/bg.png" alt="section-bg-element" class="dark d-none d-lg-block">
        <span class="bg-color d-lg-none"></span>
        </div>
    </div>
    <div class="container">
        <div class="banner__wrapper">
        <div class="row gy-5 gx-4">
            <div class="col-lg-6 col-md-7">
            <div class="banner__content" data-aos="fade-right" data-aos-duration="1000">
                <div class="banner__content-coin">
                <img src="assets/images/banner/home1/3.png" alt="coin icon">
                </div>
                <h1 class="banner__content-heading">WELCOME TO <span>RESEARCHLYNE.COM</span></h1> 
                <p class="banner__content-moto">Recommendation of 2 Quality Stocks Weekly with Analysis Reports.
                </p>
                <div class="banner__btn-group btn-group">
                <a href="#" class="trk-btn trk-btn--primary trk-btn--arrow">
                    About Us<span><i class="fa-solid fa-arrow-right"></i></span> 
                </a>
                <a href="#" class="trk-btn trk-btn--primary trk-btn--arrow">
                    Subscribe <span><i class="fa-solid fa-arrow-right"></i></span>
                </a>
                </div>
                <div class="banner__content-social">
                <p>Follow Us</p>
                <ul class="social">
                    <li class="social__item">
                    <a href="#" class="social__link social__link--style1 active"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li class="social__item">
                    <a href="#" class="social__link social__link--style1"><i class="fab fa-linkedin-in"></i></a>
                    </li>
                    <li class="social__item">
                    <a href="#" class="social__link social__link--style1"><i class="fab fa-instagram"></i></a>
                    </li>
                    <li class="social__item">
                    <a href="#" class="social__link social__link--style1"><i class="fab fa-youtube"></i></a>
                    </li>
                    <li class="social__item">
                    <a href="signin.html" class="social__link social__link--style1"><i class="fab fa-twitter"></i></a>
                    </li>
                </ul>
                </div>
            </div>
            </div>
            <div class="col-lg-6 col-md-5">
            <div class="banner__thumb" data-aos="fade-left" data-aos-duration="1000">
                <img src="assets/images/banner/home1/1.png" alt="banner-thumb" class="dark">
            </div>
            </div>
        </div>
        </div>
    </div>
    <div class="banner__shape">
        <span class="banner__shape-item banner__shape-item--1"><img src="assets/images/banner/home1/4.png"
            alt="shape icon"></span>
    </div>

</section>
<!-- ===============>> Banner section end here <<================= -->

  <!-- ===============>> partner section start here <<================= -->
  <div class="partner partner--gradient">
    <div class="container">
      <div class="partner__wrapper">
        <div class="partner__slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="partner__item">
                <div class="partner__item-inner">
                    <h4 class="dark">
                        <span>Get Jaw Dropping Discounts Upto 55% Off on Subscriptions. Offers Ending Soon, Hurry Up!</span>
                    </h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- ===============>> partner section end here <<================= -->

  <!-- ===============>> About section start here <<================= -->
  <section class="about about--style1 ">
    <div class="container">
      <div class="about__wrapper">
        <div class="row gx-5  gy-4 gy-sm-0  align-items-center">
          <div class="col-lg-6">
            <div class="about__thumb pe-lg-5" data-aos="fade-right" data-aos-duration="800">
              <div class="about__thumb-inner">
                <div class="about__thumb-image floating-content">
                  <img class="dark" src="assets/images/about/1.png" alt="about-image">
                  <div class="floating-content__top-left" data-aos="fade-right" data-aos-duration="1000">
                    <div class="floating-content__item">
                      <h3> <span class="purecounter" data-purecounter-start="0" data-purecounter-end="10">30</span>
                        Years
                      </h3>
                      <p>Experience</p>
                    </div>
                  </div>
                  <div class="floating-content__bottom-right" data-aos="fade-right" data-aos-duration="1000">
                    <div class="floating-content__item">
                      <h3> <span class="purecounter" data-purecounter-start="0" data-purecounter-end="25">25K</span>K+
                      </h3>
                      <p>Satisfied Customers</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="about__content" data-aos="fade-left" data-aos-duration="800">
              <div class="about__content-inner">
                <h2><span>SEBI</span> Registered Research Analyst <span>(INH100010013)</span></h2>

                <p class="mb-0">Mr. Amiteshwar Singh is Proprietor of M/s Amiteshwar.in and Researchlyne.com is a unit of Amiteshwar.in.
                     Researchlyne.com is exclusively focused on research of Mutli-Cap Stocks and is backed by skilled research analyst who has more than half
                      a decade of experience in stock market. Through this website the Research Analyst is trying to offer good researched stocks to
                       its subscribers. 
                    </p>
                <a href="#" class="trk-btn trk-btn--border trk-btn--primary">Explore More </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ===============>> About section start here <<================= -->

<!-- ===============>> Recent Performer section start here <<================= -->
  <section class="blog padding-top padding-bottom">
    <div class="container">
      <div class="section-header d-md-flex align-items-center justify-content-between">
        <div class="section-header__content">
          <h2 class="mb-10"><span>Recent</span> Performers</h2>
          <p class="mb-0"></p>
        </div>
        <div class="section-header__action">
          <div class="swiper-nav swiper-nav--style1">
            <button class="swiper-nav__btn blog__slider-prev"><i class="fa-solid fa-angle-left"></i></button>
            <button class="swiper-nav__btn blog__slider-next active"><i class="fa-solid fa-angle-right"></i></button>
          </div>
        </div>
      </div>
      <div class="blog__wrapper" data-aos="fade-up" data-aos-duration="1000">
        <div class="blog__slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="blog__item blog__item--style2">
                <div class="blog__item-inner">
                  <div class="blog__content">
                    <div class="blog__meta">
                      <span class="blog__meta-tag blog__meta-tag--style1">+42.58% (Within 24 weeks)</span>
                    </div>
                    <h5 class="10"> <a href="blog-details.html">Steel Authority of India Ltd.</a> </h5>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Description</th>
                                <th scope="col">Date</th>
                                <th scope="col">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="custom-border">Rec. Price</td>
                                <td class="custom-border no-border-right">14-Feb-2024</td>
                                <td class="custom-border">122.95</td>
                            </tr>
                            <tr>
                                <td class="custom-border">High Price</td>
                                <td class="custom-border no-border-right">22-May-2024</td>
                                <td class="custom-border">175.35</td>
                            </tr>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
                <div class="blog__item blog__item--style2">
                  <div class="blog__item-inner">
                    <div class="blog__content">
                      <div class="blog__meta">
                        <span class="blog__meta-tag blog__meta-tag--style1">+42.58% (Within 24 weeks)</span>
                      </div>
                      <h5 class="10"> <a href="#">Steel Authority of India Ltd.</a> </h5>
                      <table class="table table-bordered">
                          <thead>
                              <tr>
                                  <th scope="col">Description</th>
                                  <th scope="col">Date</th>
                                  <th scope="col">Price</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>
                                  <td class="custom-border">Rec. Price</td>
                                  <td class="custom-border no-border-right">14-Feb-2024</td>
                                  <td class="custom-border">122.95</td>
                              </tr>
                              <tr>
                                  <td class="custom-border">High Price</td>
                                  <td class="custom-border no-border-right">22-May-2024</td>
                                  <td class="custom-border">175.35</td>
                              </tr>
                          </tbody>
                      </table>
                    </div>
                  </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="blog__item blog__item--style2">
                    <div class="blog__item-inner">
                        <div class="blog__content">
                            <div class="blog__meta">
                            <span class="blog__meta-tag blog__meta-tag--style1">+42.58% (Within 24 weeks)</span>
                            </div>
                            <h5 class="10"> <a href="blog-details.html">Steel Authority of India Ltd.</a> </h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Description</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="custom-border">Rec. Price</td>
                                        <td class="custom-border no-border-right">14-Feb-2024</td>
                                        <td class="custom-border">122.95</td>
                                    </tr>
                                    <tr>
                                        <td class="custom-border">High Price</td>
                                        <td class="custom-border no-border-right">22-May-2024</td>
                                        <td class="custom-border">175.35</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="blog__shape">
      <span class="blog__shape-item blog__shape-item--1"> <span></span> </span>
    </div>
  </section>
<!-- ===============>> Recent Performer section start here <<================= -->

   <!-- ===============>> beyond the targets section start here <<================= -->
   <section class="testimonial padding-top padding-bottom-style2 bg-color">
    <div class="container">
      <div class="section-header d-md-flex align-items-center justify-content-between">
        <div class="section-header__content">
          <h2 class="mb-10">Beyond The <span> Targets</span></h2>
          <p class="mb-0"></p>
        </div>
        <div class="section-header__action">
          <div class="swiper-nav">
            <button class="swiper-nav__btn testimonial__slider-prev"><i class="fa-solid fa-angle-left"></i></button>
            <button class="swiper-nav__btn testimonial__slider-next active"><i
                class="fa-solid fa-angle-right"></i></button>
          </div>
        </div>
      </div>
      <div class="testimonial__wrapper" data-aos="fade-up" data-aos-duration="1000">
        <div class="testimonial__slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="testimonial__item testimonial__item--style1">
                <div class="testimonial__item-inner">
                  <div class="testimonial__item-content">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Description</th>
                                <th scope="col">Date</th>
                                <th scope="col">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="custom-border">Rec. Price</td>
                                <td class="custom-border no-border-right">14-Feb-2024</td>
                                <td class="custom-border">122.95</td>
                            </tr>
                            <tr>
                                <td class="custom-border">High Price</td>
                                <td class="custom-border no-border-right">22-May-2024</td>
                                <td class="custom-border">175.35</td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="testimonial__footer">
                      <div class="testimonial__author">
                        <div class="testimonial__author-designation">
                          <h6>+112.52% WITHIN 13 WEEKS</h6>
                          <span>Railtel Corporation of India Ltd.</span>
                        </div>
                      </div>
                      <div class="testimonial__quote">
                        <span><i class="fa-solid fa-quote-right"></i></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
                <div class="testimonial__item testimonial__item--style1">
                    <div class="testimonial__item-inner">
                    <div class="testimonial__item-content">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">Description</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="custom-border">Rec. Price</td>
                                    <td class="custom-border no-border-right">14-Feb-2024</td>
                                    <td class="custom-border">122.95</td>
                                </tr>
                                <tr>
                                    <td class="custom-border">High Price</td>
                                    <td class="custom-border no-border-right">22-May-2024</td>
                                    <td class="custom-border">175.35</td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="testimonial__footer">
                        <div class="testimonial__author">
                            <div class="testimonial__author-designation">
                            <h6>+112.52% WITHIN 13 WEEKS</h6>
                            <span>Railtel Corporation of India Ltd.</span>
                            </div>
                        </div>
                        <div class="testimonial__quote">
                            <span><i class="fa-solid fa-quote-right"></i></span>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
            <div class="testimonial__item testimonial__item--style1">
                <div class="testimonial__item-inner">
                <div class="testimonial__item-content">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Description</th>
                                <th scope="col">Date</th>
                                <th scope="col">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="custom-border">Rec. Price</td>
                                <td class="custom-border no-border-right">14-Feb-2024</td>
                                <td class="custom-border">122.95</td>
                            </tr>
                            <tr>
                                <td class="custom-border">High Price</td>
                                <td class="custom-border no-border-right">22-May-2024</td>
                                <td class="custom-border">175.35</td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="testimonial__footer">
                    <div class="testimonial__author">
                        <div class="testimonial__author-designation">
                        <h6>+112.52% WITHIN 13 WEEKS</h6>
                        <span>Railtel Corporation of India Ltd.</span>
                        </div>
                    </div>
                    <div class="testimonial__quote">
                        <span><i class="fa-solid fa-quote-right"></i></span>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ===============>> beyond the targets section start here <<================= -->

<!-- ===============>> Service section start here <<================= -->
<section class="service padding-top padding-bottom">
    <div class="section-header section-header--max50">
        <h2 class="mb-10 mt-minus-5">Our Features & <span>Specialisations</span></h2>
        <p>Researchlyne.com is exclusively focused on research of Mutli-Cap Stocks and is backed by skilled 
        research analyst who has more than half a decade of experience in stock market. 
        Through this website the Research Analyst is trying to offer good researched stocks to its subscribers.</p>
    </div>
    <div class="container">
        <div class="service__wrapper">
        <div class="row g-4 align-items-center">
            <div class="col-sm-6 col-md-6 col-lg-3">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="800">
                <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                    <img class="dark" src="assets/images/service/1.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                    <h5 > <a class="stretched-link" href="#">Exclusive Research</a> </h5>
                    <p class="mb-0">Using our enriched experience to find quality businesses at fundamentally reasonable value, to help our subscribers in wealth creation.</p>
                </div>
                </div>
            </div>
            </div>
            <div class="col-sm-6 col-lg-3">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1000">
                <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                    <img class="dark" src="assets/images/service/2.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                    <h5 > <a class="stretched-link" href="service-details.html"> Multi-Cap Model</a> </h5>
                    <p class="mb-0">We are offering a Unique Multi-Cap Strategy, to help our subscribers to diversify their investments.
                    </p>
                </div>
                </div>
            </div>
            </div>
            <div class="col-sm-6 col-lg-3">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1200">
                <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                    <img class="dark" src="assets/images/service/3.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                    <h5 > <a class="stretched-link" href="service-details.html">Low Prices</a> </h5>
                    <p class="mb-0">Researchlyne.com is focused on providing its subscribers with quality services at competitively low prices.</p>
                </div>
                </div>
            </div>
            </div>
            <div class="col-sm-6 col-lg-3">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="800">
                <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                    <img class="dark" src="assets/images/service/4.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                    <h5 > <a class="stretched-link" href="service-details.html">24*7 In-Depth Analysis </a>
                    </h5>
                    <p class="mb-0">We work round the clock to offer quality stocks at attractive value to our subscribers.</p>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
</section>
<!-- ===============>> Service section start here <<================= -->
    

  <!-- ========== Roadmap Section start Here========== -->
  <section class="roadmap roadmap--style1 padding-top  padding-bottom bg-color" id="roadmap">
    <div class="container">
      <div class="section-header section-header--max50">
        <h2 class="mb-10 mt-minus-5">What Makes Us Your <span>Best Choice.</span></h2>
        <p></p>
      </div>
      <div class="roadmap__wrapper">
        <div class="row gy-4 gy-md-0 gx-5">
          <div class="col-md-6 offset-md-6">
            <div class="roadmap__item ms-md-4 aos-init aos-animate" data-aos="fade-left" data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3>SERIOUS INVESTING</h3>
                    <span>P1</span>
                  </div>
                  <p>Researchlyne.com is for the earnest investors who are willing to build wealth and increase their earnings in long run. To achieve this, we study plethora of listed companies of Indian Stock Market and choose only those companies that have potential to be called good investment.</p>
                </div>
              </div>

            </div>
          </div>
          <div class="col-md-6">
            <div class="roadmap__item roadmap__item--style2 ms-auto me-md-4 aos-init aos-animate" data-aos="fade-right"
              data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3>AUTOMATIC DIVERSIFICATION IN EQUITIES</h3>
                    <span>P2</span>
                  </div>
                  <p>With thorough analysis, we recommend 2 Mutli-Cap Stocks every week. This Multi-Cap model helps the subscribers to make hybrid investments decision i.e. combination of aggressive & conservative approach.</p>
                </div>
              </div>

            </div>
          </div>
          <div class="col-md-6 offset-md-6">
            <div class="roadmap__item ms-md-4 aos-init" data-aos="fade-left" data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3>OUR AIM</h3>
                    <span>P3</span>
                  </div>
                  <p>The aim of our recommendations is to help the subscribers increase the monetary benefit by of investment in different recommended stocks. Therefore, selling the same whenever they achieve the predicted target value. This will help the subscribers to realise the gains and give them confidence to further invest in recommended stocks of future.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="roadmap__item roadmap__item--style2 ms-auto me-md-4 aos-init" data-aos="fade-right"
              data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3>OUR SUGGESTION</h3>
                    <span>P4</span>
                  </div>
                  <p>We don’t recommend stocks for intraday trading and don’t encourage you to go for futures and options, as we do not want any of our valuable subscriber to lose even single penny by way of speculation.</p>
                </div>
              </div>

            </div>
          </div>
          <div class="col-md-6 offset-md-6">
            <div class="roadmap__item ms-md-4 aos-init" data-aos="fade-left" data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3>OUR RECOMMENDATION</h3>
                    <span>P5</span>
                  </div>
                  <p>By availing our subscription, the Subscribers will get recommendation of 2 Mutli-Cap Stocks i.e. 1 on Wednesday and 1 on Saturday along with analysis report about the Company’s financials and market prospects as well as the target price of the stock.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="roadmap__shape">
      <span class="roadmap__shape-item roadmap__shape-item--1"> <span></span> </span>
      <span class="roadmap__shape-item roadmap__shape-item--2"> <img src="assets/images/icon/1.png" alt="shape-icon">
      </span>
    </div>
  </section>
  <!-- ========== Roadmap Section Ends Here========== -->

  <!-- ===============>> Pricing section start here <<================= -->
  <section class="pricing padding-top padding-bottom">
    <div class="section-header section-header--max50">
      <h2 class="mb-10 mt-minus-5">Our <span>Subscription </span>plan</h2>
      <p>GET LOGIN DETAILS AFTER SUBSCRIPTION</p>
    </div>
    <div class="container">
      <div class="pricing__wrapper">
        <div class="row g-4 align-items-center">
          <div class="col-md-6 col-lg-4">
            <div class="pricing__item" data-aos="fade-right" data-aos-duration="1000">
              <div class="pricing__item-inner">
                <div class="pricing__item-content">

                  <!-- pricing top part -->
                  <div class="pricing__item-top">
                    <h6 class="mb-15">Basic Plan</h6>
                    <h3 class="mb-25">Rs 1950<span>/For 3 Months</span> </h3>
                  </div>

                  <!-- pricing middle part -->
                  <div class="pricing__item-middle">
                    <ul class="pricing__list">
                      <li class="pricing__list-item"><span><img src="assets/images/icon/check.svg" alt="check"
                            class="dark"></span>
                            Rs.3000/-35% off</li>
                      <li class="pricing__list-item"><span><img src="assets/images/icon/check.svg" alt="check"
                            class="dark"></span>
                            You Save Rs.1050/-</li>
                    </ul>

                  </div>

                  <!-- pricing bottom part -->
                  <div class="pricing__item-bottom">
                    <p><span class="fa fa-check dark"></span> I agree to Terms & Conditions and Privacy Policy</p>
                    <a href="signup.html" class="trk-btn trk-btn--outline">Choose Plan</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4">
            <div class="pricing__item" data-aos="fade-right" data-aos-duration="1000">
              <div class="pricing__item-inner">
                <div class="pricing__item-content">

                  <!-- pricing top part -->
                  <div class="pricing__item-top">
                    <h6 class="mb-15">Standard Plan</h6>
                    <h3 class="mb-25">Rs 3300<span>/For 6 Months</span> </h3>
                  </div>

                  <!-- pricing middle part -->
                  <div class="pricing__item-middle">
                    <ul class="pricing__list">
                      <li class="pricing__list-item"><span><img src="assets/images/icon/check.svg" alt="check"
                            class="dark"></span>
                            Rs.6000/-45% off</li>
                      <li class="pricing__list-item"><span><img src="assets/images/icon/check.svg" alt="check"
                            class="dark"></span>
                            You Save Rs.2700/-</li>
                    </ul>

                  </div>

                  <!-- pricing bottom part -->
                  <div class="pricing__item-bottom">
                    <p><span class="fa fa-check dark"></span> I agree to Terms & Conditions and Privacy Policy</p>
                    <a href="signup.html" class="trk-btn trk-btn--outline">Choose Plan</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4">
            <div class="pricing__item" data-aos="fade-right" data-aos-duration="1000">
              <div class="pricing__item-inner">
                <div class="pricing__item-content">

                  <!-- pricing top part -->
                  <div class="pricing__item-top">
                    <h6 class="mb-15">Value Plan</h6>
                    <h3 class="mb-25">Rs 5400<span>/For 12 Months</span> </h3>
                  </div>

                  <!-- pricing middle part -->
                  <div class="pricing__item-middle">
                    <ul class="pricing__list">
                      <li class="pricing__list-item"><span><img src="assets/images/icon/check.svg" alt="check"
                            class="dark"></span>
                            Rs.12000/-55% off</li>
                      <li class="pricing__list-item"><span><img src="assets/images/icon/check.svg" alt="check"
                            class="dark"></span>
                            You Save Rs.6600/-</li>
                    </ul>

                  </div>

                  <!-- pricing bottom part -->
                  <div class="pricing__item-bottom">
                    <p><span class="fa fa-check dark"></span> I agree to Terms & Conditions and Privacy Policy</p>
                    <a href="signup.html" class="trk-btn trk-btn--outline">Choose Plan</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="pricing__shape">
      <span class="pricing__shape-item pricing__shape-item--1"> <span></span> </span>
      <span class="pricing__shape-item pricing__shape-item--2"> <img src="assets/images/icon/1.png" alt="shape-icon">
      </span>
    </div>
  </section>
  <!-- ===============>> Pricing section start here <<================= -->

  <!-- ===============>> FAQ section start here <<================= -->
  <section class="faq padding-top padding-bottom of-hidden">
    <div class="section-header section-header--max65">
      <h2 class="mb-10 mt-minus-5"><span>FAQs</span> (Frequently Asked Questions)</h2>
      <p></p>
    </div>
    <div class="container">
      <div class="faq__wrapper">
        <div class="row g-5 align-items-center justify-content-between">
          <div class="col-lg-6">
            <div class="accordion accordion--style1" id="faqAccordion1" data-aos="fade-right" data-aos-duration="1000">
              <div class="row">
                <div class="col-12">
                  <div class="accordion__item accordion-item">
                    <div class="accordion__header accordion-header" id="faq1">
                      <button class="accordion__button accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#faqBody1" aria-expanded="false" aria-controls="faqBody1">
                        <span class="accordion__button-content">How will i get recommendations?</span>
                      </button>
                    </div>
                    <div id="faqBody1" class="accordion-collapse collapse show" aria-labelledby="faq1"
                      data-bs-parent="#faqAccordion1">
                      <div class="accordion__body accordion-body">
                        <p class="mb-15">
                            You will get recommendation of 2 stocks weekly. You will be able to see the Analysis Report of the Recommended stocks i.e. 1 stock on Wednesday and 1 stock on Saturday Evening around 6:00 PM by using Login Details provided to you after subscribing.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="accordion__item accordion-item">
                    <div class="accordion__header accordion-header" id="faq2">
                      <button class="accordion-button accordion__button collapsed" type="button"
                        data-bs-toggle="collapse" data-bs-target="#faqBody2" aria-expanded="true"
                        aria-controls="faqBody2">
                        <span class=" accordion__button-content">What is the holding periods of the stock?</span>
                      </button>
                    </div>
                    <div id="faqBody2" class="accordion-collapse collapse" aria-labelledby="faq2"
                      data-bs-parent="#faqAccordion1">
                      <div class="accordion__body accordion-body">
                        <p class="mb-15">
                            We expect a return of around 25% within next 4 months. But we always suggest to book profits whenever any stock price reaches its target price.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="faq__thumb faq__thumb--style1" data-aos="fade-left" data-aos-duration="1000">
              <img class="dark" src="assets/images/others/1.png" alt="faq-thumb">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="faq__shape faq__shape--style1">
      <span class="faq__shape-item faq__shape-item--1"><img src="assets/images/others/2.png" alt="shpae-icon"></span>
    </div>
  </section>
  <!-- ===============>> FAQ section start here <<================= -->

    <!-- ===============>> Contact section start here <<================= -->
    <div class="contact padding-top padding-bottom">
        <div class="container">
          <div class="contact__wrapper">
            <div class="row g-5">
              <div class="col-md-5">
                <div class="contact__info" data-aos="fade-right" data-aos-duration="1000">
                  <div class="contact__social">
                    <h3><span>SEBI</span> Registered Research Analyst (INH100010013).</h3>
                    <p>Mr. Amiteshwar Singh is Proprietor of M/s Amiteshwar.in and Researchlyne.com is a unit of Amiteshwar.in.
                        Researchlyne.com is exclusively focused on research of Mutli-Cap Stocks and is backed by skilled research analyst 
                        who has more than half a decade of experience in stock market. Through this website the Research Analyst is trying 
                        to offer good researched stocks to its subscribers.
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-7">
                <div class="contact__form">
                  <form action="#" data-aos="fade-left" data-aos-duration="1000">
                    <div class="row g-4">
                      <div class="col-6">
                        <div>
                          <input class="form-control" type="text" id="name" placeholder="Full Name">
                        </div>
                      </div>
                      <div class="col-6">
                        <div>
                          <input class="form-control" type="email" id="email" placeholder="Email here">
                        </div>
                      </div>
                      <div class="col-6">
                        <div>
                          <input class="form-control" type="text" id="mobile" placeholder="Mobile here">
                        </div>
                      </div>
                      <div class="col-6">
                        <div>
                          <input class="form-control" type="text" id="subject" placeholder="Subject here">
                        </div>
                      </div>
                      <div class="col-12">
                        <div>
                          <textarea cols="30" rows="3" class="form-control" id="textarea"
                            placeholder="Enter Your Message"></textarea>
                        </div>
                      </div>
                    </div>
                    <button type="submit" class="trk-btn trk-btn--border trk-btn--primary mt-4 d-block">Send Message</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="contact__shape">
          <span class="contact__shape-item contact__shape-item--1"><img src="assets/images/contact/4.png"
              alt="shape-icon"></span>
          <span class="contact__shape-item contact__shape-item--2"> <span></span> </span>
        </div>
      </div>
      <!-- ===============>> Contact section start here <<================= -->
    
    
@endsection
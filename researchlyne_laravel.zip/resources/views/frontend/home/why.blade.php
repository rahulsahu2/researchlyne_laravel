@extends('layouts.app')
@section('content')
@include('frontend.components.sub-header', ['title' => 'Why Researchlyne.com'])
@include('frontend.components.benefits-section', ['data' => null])
@endsection